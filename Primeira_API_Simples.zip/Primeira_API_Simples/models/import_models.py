from models.papel import Papel
from models.cotacao import Cotacao
from models.usuario import Usuario